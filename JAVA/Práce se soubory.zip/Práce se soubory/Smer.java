/* UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */




/*******************************************************************************
 * Instance výčtového typu {@code Smer} představují ...
 * The {@code Smer} enum type instances represent ...
 *
 * @author  author name
 * @version 0.00.0000 — 20yy-mm-dd
 */
public enum Smer
{
    SEVER("Sever"),
    VYCHOD("Vychod"),
    JIH("Jih"),
    ZAPAD("Zapad"),
    SEVEROZAPAD("Severozapad"),
    SEVEROVYCHOD("Severovychod"),
    JIHOVYCHOD("Jihovychod"),
    JIHOZAPAD("Jihozapad");
    private Smer(String smer)
    {
        
    }

}
