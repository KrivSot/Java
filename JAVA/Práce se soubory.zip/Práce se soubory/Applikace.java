/* UTF-8 codepage: Příliš žluťoučký kůň úpěl ďábelské ódy. ÷ × ¤
 * «Stereotype», Section mark-§, Copyright-©, Alpha-α, Beta-β, Smile-☺
 */



import java.util.concurrent.ThreadLocalRandom;
import java.util.Scanner;
/*******************************************************************************
 * Třída {@code App} je hlavní třídou projektu,
 * který ...
 *
 * @author  author name
 * @version 0.00.0000 — 20yy-mm-dd
 */
public class Applikace
{
    /***************************************************************************
     * Metoda, prostřednictvím níž se spouští celá aplikace.
     *
     * @param args Parametry příkazového řádku
     */
    public static void main(String[] args)throws InterruptedException
    {
       /*Osoby osb = new Osoby();
       System.out.println("Chce jet " +osb.PocetOsob()+" z toho "+osb.Ridici()+" mají auto");
       System.out.println("Kolik lidí chcete nabrat ?");
       osb.jet();*/
    }
}
