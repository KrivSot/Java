 

import java.awt.Component;

public class JLable extends Component {

}
