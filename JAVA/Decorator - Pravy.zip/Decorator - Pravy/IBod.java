import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;



/*******************************************************************************
 * Instance interfejsu {@code ITvar} představují ...
 * The {@code ITvar} interface instances represent ...
 *
 * @author  author name
 * @version 0.00.0000 — 20yy-mm-dd
 */
public interface IBod
{
    public void vykresli();
    public int getBodX();
    public int getBodY();
}
